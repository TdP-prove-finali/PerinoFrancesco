package it.polito.tdp.tesi.model;

public class Route {
	
	public Route(int routeId, String shortName, String longName) {
		super();
		this.routeId = routeId;
		this.shortName = shortName;
		this.longName = longName;
	}
	public Route(int routeId) {
		this.routeId=routeId;
	}
	int routeId;
	String shortName;
	String longName;
	long attesa;
	
	public long getAttesa() {
		return attesa;
	}
	public void setAttesa(long attesa) {
		this.attesa = attesa;
	}
	public int getRouteId() {
		return routeId;
	}
	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getLongName() {
		return longName;
	}
	public void setLongName(String longName) {
		this.longName = longName;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + routeId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Route other = (Route) obj;
		if (routeId != other.routeId)
			return false;
		return true;
	}
	
	

}
