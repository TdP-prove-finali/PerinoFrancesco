/**
 * Sample Skeleton for 'Tesi.fxml' Controller Class
 */

package it.polito.tdp.tesi;

import java.net.URL;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import org.jgrapht.graph.DefaultWeightedEdge;

import it.polito.tdp.tesi.model.Model;
import it.polito.tdp.tesi.model.Museo;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.TextArea;

public class TesiController {

    @FXML // ResourceBundle that was given to the FXMLLoader
    private ResourceBundle resources;

    @FXML // URL location of the FXML file that was given to the FXMLLoader
    private URL location;

    @FXML // fx:id="pickData"
    private DatePicker pickData; // Value injected by FXMLLoader

    @FXML // fx:id="btnaggiungi"
    private Button btnaggiungi; // Value injected by FXMLLoader

    @FXML // fx:id="cbMusei"
    private ChoiceBox<Museo> cbMusei; // Value injected by FXMLLoader

    @FXML // fx:id="btnCalcola"
    private Button btnCalcola; // Value injected by FXMLLoader

    @FXML // fx:id="txtScelti"
    private TextArea txtScelti; // Value injected by FXMLLoader

    @FXML // fx:id="txtResult"
    private TextArea txtResult; // Value injected by FXMLLoader
    @FXML // fx:id="cbOre"
    private ChoiceBox<Integer> cbOre; // Value injected by FXMLLoader

    @FXML // fx:id="cbMinuti"
    private ChoiceBox<Integer> cbMinuti; // Value injected by FXMLLoader
    @FXML // fx:id="btnReset"
    private Button btnReset; // Value injected by FXMLLoader

    

	private Model model;
	private List<Museo> daVisitare = new ArrayList<Museo>();
	List<List<Museo>> percorsiTotale; 
	List<Museo> percorsoParziale; 
	LocalTime time;
	LocalDateTime dateTime;
	LocalDate localdate;
    @FXML
    void doAggiungi(ActionEvent event) {
    	Museo m = cbMusei.getValue();
    	if(m!=null)
    	{
    		if(!this.daVisitare.contains(m))
    		{
    			this.daVisitare.add(m);
    			txtScelti.appendText(m+"\n"); 
    		}
        		
    	}
    	
    	
    }
    @FXML
    void trovaMuseiAperti(ActionEvent event) {
    	
    	cbMusei.getItems().clear();
    	txtScelti.clear();
    	localdate = pickData.getValue();
    	model.getAllMusei();
    	cbMusei.getItems().addAll(model.getAllMuseiAperti(localdate.getDayOfWeek().getValue()));
    	
    	
    }

    @FXML
    void doCalcola(ActionEvent event) {
    	if(cbOre.getValue()!=null && cbMinuti.getValue()!=null && cbMinuti.getValue()!=null && daVisitare.size()>0)
    	{
    		System.out.println(LocalTime.now());
    		time = LocalTime.of(cbOre.getValue(), cbMinuti.getValue());
    	
    		dateTime = LocalDateTime.of(localdate, time);
    	//txtScelti.appendText(date+"");
    	
    	percorsiTotale = new ArrayList<List<Museo>>();
    	percorsoParziale = new ArrayList<Museo>();
    	model.setDaVisitare(daVisitare);
    	model.creaVertici(dateTime.toLocalDate());
    	model.trovaPercorsiPossibili(0, daVisitare, percorsoParziale, daVisitare.size(), percorsiTotale);
    	
    	//txtResult.setText("gas");
    	
    	List<DefaultWeightedEdge> percorso = model.percorsoMigliore(percorsiTotale, dateTime);
    	
    	//for(DefaultWeightedEdge dd : percorso)
    	
    		
    	if(model.isCompleto()==true)
    		{
    		String tempo = 	(int)(model.getTempoMigliore()/60)+" ore e "+(int)(model.getTempoMigliore()-60*(int)(model.getTempoMigliore()/60))+" minuti";
    			txtResult.appendText("Il percorso � completo \n");
    		
    			txtResult.appendText(model.stampaRisultato(percorso)+"\n");
    			System.out.print(percorso);
    			txtResult.appendText("Tempo percorso totale : "+tempo);
    			System.out.println("\n"+LocalTime.now());
    		}
    	else if(model.isUnicoMuseo()==true)
    		{
    			txtResult.appendText("Si pu� visitare un unico museo \n");
    			txtResult.appendText(model.getUnicoMuseoVisitato()+"");
    			System.out.println(LocalTime.now());
    		}
    	else
    	{
    		String tempo = 	(int)(model.getTempoPercorsoIncompletoMigliore()/60)+" ore e "+(int)(model.getTempoPercorsoIncompletoMigliore()-60*(int)(model.getTempoPercorsoIncompletoMigliore()/60))+" minuti";
    		System.out.print(percorso);
    		txtResult.appendText("Il percorso � incompleto \n");
    		txtResult.appendText(model.stampaRisultato(percorso)+"\n");
			txtResult.appendText("Tempo percorso  : "+tempo);
			System.out.println(LocalTime.now());
    	}
    	
    }
    	
    	
    	
    }
    @FXML
    void doReset(ActionEvent event) {
    	txtScelti.clear();
    	txtResult.clear();
    	daVisitare.clear();
    }
    

    @FXML // This method is called by the FXMLLoader when initialization is complete
    void initialize() {
        assert pickData != null : "fx:id=\"pickData\" was not injected: check your FXML file 'Tesi.fxml'.";
        assert btnaggiungi != null : "fx:id=\"btnaggiungi\" was not injected: check your FXML file 'Tesi.fxml'.";
        assert cbMusei != null : "fx:id=\"cbMusei\" was not injected: check your FXML file 'Tesi.fxml'.";
        assert btnCalcola != null : "fx:id=\"btnCalcola\" was not injected: check your FXML file 'Tesi.fxml'.";
        assert txtScelti != null : "fx:id=\"txtScelti\" was not injected: check your FXML file 'Tesi.fxml'.";
        assert txtResult != null : "fx:id=\"txtResult\" was not injected: check your FXML file 'Tesi.fxml'.";
        assert cbOre != null : "fx:id=\"cbOre\" was not injected: check your FXML file 'Tesi.fxml'.";
        assert cbMinuti != null : "fx:id=\"cbMinuti\" was not injected: check your FXML file 'Tesi.fxml'.";
        assert btnReset != null : "fx:id=\"btnReset\" was not injected: check your FXML file 'Tesi.fxml'.";

    }
   
    
    public void setModel(Model model)
    {
    	this.model= model;
    	
    	//cbMusei.getItems().addAll(model.getAllMusei());
    	for(int i = 0;i<=24;i++)
    		cbOre.getItems().add(i);
    	for(int i = 0;i<=60;i++)
    		cbMinuti.getItems().add(i);
    }
}

