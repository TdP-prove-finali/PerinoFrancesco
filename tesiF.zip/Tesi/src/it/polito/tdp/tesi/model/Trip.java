package it.polito.tdp.tesi.model;

public class Trip {
	
	public Trip(int routeId, int tripId) {
		super();
		this.routeId = routeId;
		this.tripId = tripId;
	}
	int routeId;
	int tripId;
	public int getRouteId() {
		return routeId;
	}
	public void setRouteId(int routeId) {
		this.routeId = routeId;
	}
	public int getTripId() {
		return tripId;
	}
	public void setTripId(int tripId) {
		this.tripId = tripId;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + routeId;
		result = prime * result + tripId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Trip other = (Trip) obj;
		if (routeId != other.routeId)
			return false;
		if (tripId != other.tripId)
			return false;
		return true;
	}
	
}
