package it.polito.tdp.tesi.model;

public class StopCollegati {
	
	Stop s1;
	Stop s2;
	double distanza;
	public Stop getS1() {
		return s1;
	}
	public void setS1(Stop s1) {
		this.s1 = s1;
	}
	public Stop getS2() {
		return s2;
	}
	public void setS2(Stop s2) {
		this.s2 = s2;
	}
	public double getDistanza() {
		return distanza;
	}
	public void setDistanza(double distanza) {
		this.distanza = distanza;
	}
	public StopCollegati(Stop s1, Stop s2, double distanza) {
		super();
		this.s1 = s1;
		this.s2 = s2;
		this.distanza = distanza;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(distanza);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((s1 == null) ? 0 : s1.hashCode());
		result = prime * result + ((s2 == null) ? 0 : s2.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StopCollegati other = (StopCollegati) obj;
		if (Double.doubleToLongBits(distanza) != Double.doubleToLongBits(other.distanza))
			return false;
		if (s1 == null) {
			if (other.s1 != null)
				return false;
		} else if (!s1.equals(other.s1))
			return false;
		if (s2 == null) {
			if (other.s2 != null)
				return false;
		} else if (!s2.equals(other.s2))
			return false;
		return true;
	}
	
	

}
