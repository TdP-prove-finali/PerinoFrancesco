package it.polito.tdp.tesi.db;

import java.sql.*;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.util.ArrayList;
import java.sql.Date;

import java.util.LinkedList;
import java.util.List;

import org.jgrapht.graph.DefaultDirectedWeightedGraph;
import org.jgrapht.graph.DefaultWeightedEdge;

import it.polito.tdp.tesi.model.AttesaRoute;
import it.polito.tdp.tesi.model.CalendarDate;
import it.polito.tdp.tesi.model.Collegamento;
import it.polito.tdp.tesi.model.Luogo;
import it.polito.tdp.tesi.model.Museo;
import it.polito.tdp.tesi.model.MuseoCollegatoStop;
import it.polito.tdp.tesi.model.MuseoVicinoMusei;
import it.polito.tdp.tesi.model.Route;
import it.polito.tdp.tesi.model.Stop;
import it.polito.tdp.tesi.model.StopCollegati;
import it.polito.tdp.tesi.model.StopSuLinea;
import it.polito.tdp.tesi.model.StopTime;

import it.polito.tdp.tesi.model.Trip;


public class TesiDAO {
	
	private Stop buildStop(ResultSet rs) throws SQLException {
		return new Stop(
				rs.getInt("stop_id"),
				rs.getInt("stop_code"),
				rs.getString("stop_name"),
				rs.getDouble("stop_lat"),
				rs.getDouble("stop_lon")
				) ;
	}

	private StopTime buildStopTime(ResultSet rs) throws SQLException {
		return new StopTime(
				rs.getInt("trip_id"),
				rs.getInt("stop_id"),
				rs.getInt("stop_sequence"),
				rs.getTime("arrival_time").toLocalTime(),
				rs.getTime("departure_time").toLocalTime()
				) ;
	}
	
	private Route buildRoute(ResultSet rs) throws SQLException {
		return new Route(
				rs.getInt("route_id"),
				rs.getString("route_short_name"),
				rs.getString("route_long_name")
				) ;
	}
	
	private Trip buildTrip(ResultSet rs) throws SQLException {
		return new Trip(
				rs.getInt("route_id"),
				rs.getInt("trip_id")
				) ;
	}
	
	
	private Museo buildMuseo(ResultSet rs) throws SQLException {
		if(rs.getLong("durata_visita")>0)
			return new Museo(
				rs.getInt("id_museo"),
				rs.getString("denominaz"),
				rs.getString("indirizzo"),
				rs.getDouble("coord_x"),
				rs.getDouble("coord_y"),
				rs.getLong("durata_visita")
				) ;
		else return null;
	}
	private CalendarDate buildCalendarDate(ResultSet rs) throws SQLException {
		return new CalendarDate(
				rs.getInt("service_id"),
				rs.getDate("date").toLocalDate()
				) ;
	}
	
	
	
	
	public List<Stop> getAllStops() {
		List<Stop> stops = new ArrayList<Stop>() ;
		
		Connection conn = DBConnect.getConnection() ;
		
		String sql = "SELECT * FROM stops" ;
		
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				stops.add( buildStop(rs) ) ;
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		return stops ;
	}
	
	public List<Museo> getAllMusei() {
		List<Museo> musei = new ArrayList<Museo>() ;
		
		Connection conn = DBConnect.getConnection() ;
		
		String sql = "SELECT * FROM musei" ;
		
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				Museo m = buildMuseo(rs);
				if(m!=null)
				musei.add( m ) ;
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		return musei ;
	}
	
	public List<MuseoVicinoMusei> getAllMuseiViciniMusei(List<Museo> musei) {
		List<MuseoVicinoMusei> museoVicinoMusei = new ArrayList<MuseoVicinoMusei>() ;
		
		Connection conn = DBConnect.getConnection() ;
		
		String sql = "select * from musei_vicini_musei" ;
		
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				
			Museo p = 	musei.get(musei.indexOf(new Museo(rs.getInt("id1"))));
			Museo a = 	musei.get(musei.indexOf(new Museo(rs.getInt("id2"))));
			double distanza = rs.getDouble("distanza");
				museoVicinoMusei.add(new MuseoVicinoMusei(p,a,distanza)) ;
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		return museoVicinoMusei ;
	}
	
	public void getAllOrariMuseiByMuseoIdGiornoSettimana(int museoId,int dow,List<Museo> musei) {
		
		
		Connection conn = DBConnect.getConnection() ;
		
		String sql = "select * from orari_musei where orari_musei.museo_id=? and orari_musei.giorno_settimana=?" ;
		
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			st.setInt(1, museoId);
			st.setInt(2, dow);
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				Museo m = musei.get(musei.indexOf(new Museo(museoId)));
				m.setOrarioApertura(rs.getTime("orario_apertura").toLocalTime());
				m.setOrarioChiusura(rs.getTime("orario_chiusura").toLocalTime());
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		
	}
	
	public void getAllAtteseByRoute(int dow,LocalTime time,List<Route> routes) {
		//List<AttesaRoute> ar = new ArrayList<AttesaRoute>();
		
		Connection conn = DBConnect.getConnection() ;
		
		//String sql1 = "Select distinct t1.route_id, minuti, t2.OraMin  from trips as t1 inner join ( select route_id, dayofweek(date_add(date,INTERVAL -1 DAY)) as dow, left(min(arrival_time),2)*60+substring(min(arrival_time),4,2) as minuti, min(arrival_time) as OraMin from stop_times inner join trips on stop_times.trip_id=trips.trip_id inner join calendardate on trips.service_id=calendardate.service_id where stop_sequence=1 and date between '2016-09-12' and '2016-09-18' and arrival_time>=? and dayofweek(date_add(date,INTERVAL -1 DAY))=? group by route_id ) as t2 on t1.route_id=t2.route_id where t1.route_id=?" ;
		//String sql2 = "Select distinct t1.route_id, minuti, t2.OraMin  from trips as t1 inner join ( select route_id, dayofweek(date_add(date,INTERVAL -1 DAY)) as dow, left(min(arrival_time),2)*60+substring(min(arrival_time),4,2) as minuti, min(arrival_time) as OraMin from stop_times inner join trips on stop_times.trip_id=trips.trip_id inner join calendardate on trips.service_id=calendardate.service_id where stop_sequence=1 and date between '2016-09-12' and '2016-09-18' and arrival_time>? and dayofweek(date_add(date,INTERVAL -1 DAY))=? group by route_id ) as t2 on t1.route_id=t2.route_id where t1.route_id=?" ;
		String sql = "SELECT *,Left(arrival_time,2)*60+substring(arrival_time,4,2) AS minuti, stop_times.arrival_time AS OraMin FROM (stop_times INNER JOIN trips ON stop_times.trip_id = trips.trip_id) INNER JOIN calendardate ON trips.service_id = calendardate.service_id WHERE stop_times.arrival_time>=? AND trips.route_id=? AND stop_times.stop_sequence=1 AND dayofweek(date_add(date,INTERVAL -1 DAY))=? ORDER BY trip_headsign,stop_times.arrival_time LIMIT 2";
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			
			for(Route r : routes)
			
			{
				//ASSEGNO AD OGNI LINEA COME TEMPO DI ATTESA DI UN PULLMAN LA META' DEL MASSIMO TEMPO DI ATTESA
			st.setTime(1, Time.valueOf(time));
			st.setInt(2,r.getRouteId());
			st.setInt(3, dow);
			
			ResultSet rs = st.executeQuery() ;
			
			int minutiIniziali=0;
			int minutiFinali=0;
			String direzione="";
			boolean stop=false;
			while(rs.next() && stop==false) {
				if(minutiIniziali==0 )
					{
						minutiIniziali=rs.getInt("minuti");
						direzione=rs.getString("trip_headsign");
					}
				else if(direzione.compareTo(rs.getString("trip_headsign"))==0  )
						{
							minutiFinali=rs.getInt("minuti");
							stop=true;
						}

				
			}
				if(minutiFinali-minutiIniziali>0)
					r.setAttesa(minutiFinali-minutiIniziali);
				else
					r.setAttesa(30);
			//System.out.println(minutiIniziali);
			//System.out.println(oraMin);

			}
			st.close() ;
			
			
			
				
				
			
			//AttesaRoute attesaRoute = new AttesaRoute(route, minutiFinali-minutiIniziali);
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
	
	}
	


	public List<StopCollegati> getAllStopsVicini(List<Stop> stops) {
		List<StopCollegati> stopsCollegati = new ArrayList<StopCollegati>() ;
		
		Connection conn = DBConnect.getConnection() ;
		
		String sql = "SELECT * FROM stop_vicini" ;
		
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				
				Stop s1 = stops.get(stops.indexOf(new Stop(rs.getInt("stop_id1"))));
				Stop s2 = stops.get(stops.indexOf(new Stop(rs.getInt("stop_id2"))));
				stopsCollegati.add(new StopCollegati(s1,s2,rs.getDouble("distanza"))) ;
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		return stopsCollegati ;
	}
	
	public List<StopSuLinea> getAllStopsSuLinea(List<Stop> stops, List<Route> routes) {
		List<StopSuLinea> result = new ArrayList<StopSuLinea>() ;
		
		Connection conn = DBConnect.getConnection() ;
		
		String sql = "select * from fermatelinee" ;
		
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				//result.add( buildStopSuLinea(rs) ) ;
				int routeId = rs.getInt("route_id");
				int stopId = rs.getInt("stop_id");
				
				Stop stop = stops.get(stops.indexOf(new Stop(stopId)));
				Route route = routes.get(routes.indexOf(new Route(routeId)));
				
				StopSuLinea ssl = new StopSuLinea(stop,route);
				stop.addStopSuLinea(ssl);
				result.add(ssl);
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		return result ;
	}
	
	public List<Collegamento> getAllCollegamenti(List<Stop> stops, List<Route> routes, LocalDateTime date) {
		List<Collegamento> result = new ArrayList<Collegamento>() ;
		
		Connection conn = DBConnect.getConnection() ;
		
		// String  = "select t2.stop_id as stopP, t1.stop_id as stopA, t1.route_id as route, t2.stop_sequence , t1.stop_sequence, t1.trip_headsign, t1.dow from stoplinea as t1 inner join stoplinea as t2 on t1.route_id=t2.route_id and t1.trip_headsign=t2.trip_headsign and t1.stop_sequence=t2.stop_sequence+1 and t1.dow=t2.dow where t1.dow=dayofweek(?)" ;		
		String sql ="select * from orari inner join (select route_id, StopP, dow, min(oraP) as minOraP	from Orari where orari.dow=? and oraP>? and  oraP<=? group by route_id, StopP, dow) as Temp  on orari.route_id=temp.route_id and orari.StopP=temp.StopP and orari.OraP=temp.minorap WHERE orari.dow=?";
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
	
			st.setInt(1, date.getDayOfWeek().getValue());
			st.setTime(2, Time.valueOf(date.toLocalTime()));
			st.setTime(3, Time.valueOf(date.toLocalTime().plusMinutes(30)));
			st.setInt(4, date.getDayOfWeek().getValue());
			
			/*System.out.println(Date.valueOf(date.toLocalDate()));
			System.out.println(Time.valueOf(date.toLocalTime()));
			System.out.println( Time.valueOf(date.toLocalTime().plusMinutes(60)));*/
			
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				
				int routeId = rs.getInt("route_id");
				int stopIdPartenza = rs.getInt("stopP");
				int stopIdArrivo = rs.getInt("stopA");
				long tempo = rs.getLong("tempo");
				Stop stopPartenza = stops.get(stops.indexOf(new Stop(stopIdPartenza)));
				Stop stopArrivo = stops.get(stops.indexOf(new Stop(stopIdArrivo)));
				Route route = routes.get(routes.indexOf(new Route(routeId)));
				
				Collegamento collegamento = new Collegamento(stopPartenza,stopArrivo,route,tempo);
				result.add(collegamento);
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		return result ;
	}
	
	public List<MuseoCollegatoStop> getAllMuseiCollegatiFermate(List<Stop> stops, List<Museo> musei) {
		List<MuseoCollegatoStop> result = new ArrayList<MuseoCollegatoStop>() ;
		
		Connection conn = DBConnect.getConnection() ;
		
		String sql = "select * from museivicinifermate" ;		
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				
				
				int stopId = rs.getInt("stop_id");
				int idMuseo = rs.getInt("id_museo");
				
				Stop stop = stops.get(stops.indexOf(new Stop(stopId)));
				 try{
				Museo museo = musei.get(musei.indexOf(new Museo(idMuseo)));
				
				
				MuseoCollegatoStop collegamento = new MuseoCollegatoStop(museo,stop,rs.getDouble("distanza"));
				result.add(collegamento);
				}
				 catch(Exception e ){
					 
				 }
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		return result ;
	}
	
	public List<Route> getAllRoutes() {
		List<Route> result = new ArrayList<Route>() ;
		
		Connection conn = DBConnect.getConnection() ;
		
		String sql = "SELECT * FROM routes" ;
		
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				result.add( buildRoute(rs) ) ;
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		return result ;
	}
	
	public List<Trip> getAllTrip() {
		List<Trip> result = new ArrayList<Trip>() ;
		
		Connection conn = DBConnect.getConnection() ;
		
		String sql = "SELECT * FROM trips" ;
		
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				result.add( buildTrip(rs) ) ;
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		return result ;
	}
	
	public List<CalendarDate> getAllCalendarDate() {
		List<CalendarDate> result = new ArrayList<CalendarDate>() ;
		
		Connection conn = DBConnect.getConnection() ;
		
		String sql = "SELECT * FROM calendardate" ;
		
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				result.add( buildCalendarDate(rs) ) ;
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		return result ;
	}
	
	


	
	
	
	
	
	


	public List<StopTime> getAllStopTimes() {
		List<StopTime> result = new LinkedList<StopTime>() ;
		
		Connection conn = DBConnect.getConnection() ;
		
		String sql = "SELECT trip_id,stop_id,TIMEDIFF(arrival_time,'01:00:00') as arrival_time,TIMEDIFF(departure_time,'01:00:00') as departure_time,stop_sequence FROM stop_times where TIMEDIFF(arrival_time,'01:00:00') < '25:00:00' " ;
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				result.add( buildStopTime(rs) ) ;
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		return result ;
	}
	
	public List<StopTime> getAllStopTimesDaOra(LocalDateTime time) {
		List<StopTime> result = new LinkedList<StopTime>() ;
		
		Connection conn = DBConnect.getConnection() ;
		
		String sql = "SELECT trip_id,stop_id,TIMEDIFF(arrival_time,'01:00:00') as arrival_time,TIMEDIFF(departure_time,'01:00:00') as departure_time,stop_sequence FROM stop_times where TIMEDIFF(arrival_time,'01:00:00') < '25:00:00' " ;
		
		try {
			PreparedStatement st = conn.prepareStatement(sql) ;
			
			ResultSet rs = st.executeQuery() ;
			
			while(rs.next()) {
				result.add( buildStopTime(rs) ) ;
			}
			
			st.close() ;
			conn.close() ;
			
		} catch (SQLException e) {
			e.printStackTrace();
			throw new RuntimeException("Error in database query", e) ;
		}
		
		return result ;
	}
	
	
	
	/**
	 * Simple test of the main methods
	 * @param args <i>unused</i>
	 */
	public static void main(String args[]) {
		TesiDAO dao = new TesiDAO() ;
		
		
		
		
		
		/*List<StopTime> StopTime = dao.getAllStopTimes() ;
		
		for(StopTime s : StopTime) {
			System.out.println(s); ;
		}
		
		System.out.println(StopTime.size());*/
		//LocalTime t = LocalTime.now();
		//LocalDate date = LocalDate.of(2014, Month.SEPTEMBER, 10);
		
		//List<StopVerso> routes = dao.getAllConnessioniByRouteOraData(361, Time.valueOf(t), date) ;
		
		//System.out.println(routes.size());
		//System.out.println(Time.valueOf(t));
		//System.out.println(dao.getAllMuseiCollegatiFermate(dao.getAllStops(), dao.getAllMusei()));
		LocalDateTime d =  LocalDateTime.of(2016, 8, 2, 12, 22, 22);
		LocalTime t = LocalTime.of(9, 01, 00);
		//dao.getAllCollegamenti(dao.getAllStops(), dao.getAllRoutes(), d);
		/*for(Route r :  dao.getAllRoutes())
			{
			AttesaRoute ar = dao.getAllAtteseByRoute(r.getRouteId(), 2,t, dao.getAllRoutes());
					if(ar!=null && ar.getAttesa()>0)
				System.out.println(ar.getAttesa()+" "+ar.getRoute().getShortName()+" "+ar.getRoute().getRouteId());
			}*/
		System.out.println("gas");
		/*List<Museo> musei = dao.getAllMusei();
		Museo s1 = musei.get(musei.indexOf(new Museo(46))); //GAM
		Museo s2 = musei.get(musei.indexOf(new Museo(69))); //MUSEO DEL CINEMA
		Museo s3 = musei.get(musei.indexOf(new Museo(59))); //EGIZIO
		List<Museo> daVisitare = new ArrayList<Museo>();
		daVisitare.add(s1);
		daVisitare.add(s2);
		daVisitare.add(s3);
		
		for(Museo m : daVisitare)
			dao.getAllOrariMuseiByMuseoIdGiornoSettimana(m.getId(), d.getDayOfWeek().getValue(), musei);
		for(Museo m : daVisitare)
			System.out.println(m.getOrarioApertura()+" "+m.getOrarioChiusura());*/
		
		//dao.getAllCollegamenti(dao.getAllStops(), dao.getAllRoutes(), d);
		
		/*for(Museo m : dao.getAllMusei())
			System.out.print(m.getTempoVisita()+"\n");*/
		List<Integer> s = new ArrayList<Integer>();
		s.add(2);
		s.add(2);
		s.add(2);
		//s.get(s.size());
		//System.out.println(s.get(s.size()));
		double gas = 260;
		System.out.println((int)(gas/60)+":"+(int)(gas-60*(int)(gas/60)));
		//dao.getAllMuseiViciniMusei(dao.getAllMusei());
		List<Route> r = dao.getAllRoutes();
		 dao.getAllAtteseByRoute(2,t,r );
		 
		 System.out.println("dada");
	}
	
}
