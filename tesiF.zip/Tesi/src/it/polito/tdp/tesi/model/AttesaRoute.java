package it.polito.tdp.tesi.model;

public class AttesaRoute {
	
	Route route;
	long attesa;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + (int) (attesa ^ (attesa >>> 32));
		result = prime * result + ((route == null) ? 0 : route.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AttesaRoute other = (AttesaRoute) obj;
		if (attesa != other.attesa)
			return false;
		if (route == null) {
			if (other.route != null)
				return false;
		} else if (!route.equals(other.route))
			return false;
		return true;
	}
	public AttesaRoute(Route route, long attesa) {
		super();
		this.route = route;
		this.attesa = attesa;
	}
	public Route getRoute() {
		return route;
	}
	public void setRoute(Route route) {
		this.route = route;
	}
	public long getAttesa() {
		return attesa;
	}
	public void setAttesa(long attesa) {
		this.attesa = attesa;
	}
	

}
