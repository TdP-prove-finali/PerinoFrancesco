package it.polito.tdp.tesi.model;

public class Luogo {

	

}
