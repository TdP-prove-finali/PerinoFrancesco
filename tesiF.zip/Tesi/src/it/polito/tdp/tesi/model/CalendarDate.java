package it.polito.tdp.tesi.model;

import java.time.LocalDate;

public class CalendarDate {
	
	public CalendarDate(int serviceId, LocalDate data) {
		super();
		this.serviceId = serviceId;
		this.data = data;
	}
	int serviceId;
	LocalDate data;
	public int getServiceId() {
		return serviceId;
	}
	public void setServiceId(int serviceId) {
		this.serviceId = serviceId;
	}
	public LocalDate getData() {
		return data;
	}
	public void setData(LocalDate data) {
		this.data = data;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((data == null) ? 0 : data.hashCode());
		result = prime * result + serviceId;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		CalendarDate other = (CalendarDate) obj;
		if (data == null) {
			if (other.data != null)
				return false;
		} else if (!data.equals(other.data))
			return false;
		if (serviceId != other.serviceId)
			return false;
		return true;
	}

}
