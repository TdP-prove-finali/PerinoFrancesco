package it.polito.tdp.tesi.model;

public class Collegamento {
	
	Stop partenza;
	Stop arrivo;
	Route route;
	long tempo;
	
	public Collegamento(Stop partenza, Stop arrivo, Route route, long tempo) {
		super();
		this.partenza = partenza;
		this.arrivo = arrivo;
		this.route = route;
		this.tempo = tempo;
	}
	public Stop getPartenza() {
		return partenza;
	}
	public void setPartenza(Stop partenza) {
		this.partenza = partenza;
	}
	public Stop getArrivo() {
		return arrivo;
	}
	public void setArrivo(Stop arrivo) {
		this.arrivo = arrivo;
	}
	public Route getRoute() {
		return route;
	}
	public void setRoute(Route route) {
		this.route = route;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((arrivo == null) ? 0 : arrivo.hashCode());
		result = prime * result + ((partenza == null) ? 0 : partenza.hashCode());
		result = prime * result + ((route == null) ? 0 : route.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Collegamento other = (Collegamento) obj;
		if (arrivo == null) {
			if (other.arrivo != null)
				return false;
		} else if (!arrivo.equals(other.arrivo))
			return false;
		if (partenza == null) {
			if (other.partenza != null)
				return false;
		} else if (!partenza.equals(other.partenza))
			return false;
		if (route == null) {
			if (other.route != null)
				return false;
		} else if (!route.equals(other.route))
			return false;
		return true;
	}
	public long getTempo() {
		return tempo;
	}
	public void setTempo(long tempo) {
		this.tempo = tempo;
	}
	
	
	

}
