package it.polito.tdp.tesi.model;

import java.sql.Time;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.Month;
import java.util.*;

import org.jgrapht.Graphs;
import org.jgrapht.alg.DijkstraShortestPath;
import org.jgrapht.graph.DefaultDirectedWeightedGraph;
import org.jgrapht.graph.DefaultWeightedEdge;
import org.jgrapht.graph.DirectedWeightedMultigraph;

import com.javadocmd.simplelatlng.LatLng;
import com.javadocmd.simplelatlng.LatLngTool;
import com.javadocmd.simplelatlng.util.LengthUnit;


import it.polito.tdp.tesi.db.TesiDAO;


public class Model {
	
	DefaultDirectedWeightedGraph<Luogo,DefaultWeightedEdge> graph;
	DefaultDirectedWeightedGraph<Luogo,DefaultWeightedEdge> graphParziale;
	
	List<Route> routes = null;
	List<Stop> stops = null;
	List<StopSuLinea> stopSuLinea = null;
	List<Collegamento> collegamenti = null;
	List<Museo> musei = null;
	List<Museo> museiAperti =  new ArrayList<Museo>();
	List<Integer> posizioniMigliori =  new ArrayList<Integer>();
	List<Integer> posizioniMiglioriIncompleto =  new ArrayList<Integer>();
	long tempoPercorso;
	//List<DefaultWeightedEdge> percorso;
	List<DefaultWeightedEdge>  percorsoMigliore;
	List<DefaultWeightedEdge> percorsoIncompleto;
	List<List<DefaultWeightedEdge>> tuttiIpercorsi;
	List<Museo> daVisitare = new ArrayList<Museo>();
	double tempoMigliore = 24*60;
	boolean completo=true;
	boolean unicoMuseo=false;
	Museo unicoMuseoVisitato;
	long tempoPercorsoIncompletoMigliore=24*60;
	int visitatiPercorsoIncompleto=0;
	//boolean aperti=true;
	
	
	
	public List<Stop> getAllStops() {
		
		TesiDAO dao = new TesiDAO();
		
		stops = dao.getAllStops();
		return stops;
	}
	
	public List<Route> getAllRoutes() {
		
		TesiDAO dao = new TesiDAO();
		routes = dao.getAllRoutes();
		return routes;
	}

	public List<Trip> getAllTrip() {
	
	TesiDAO dao = new TesiDAO();
	return dao.getAllTrip();
	}

	public List<StopTime> getAllStopTimes() {
	
	TesiDAO dao = new TesiDAO();
	return dao.getAllStopTimes();
	}
	
	public List<StopSuLinea> getAllStopsSuLinea(List<Stop> stops,List<Route> routes) {
		
		TesiDAO dao = new TesiDAO();
	
		stopSuLinea = dao.getAllStopsSuLinea(stops,routes);
		return stopSuLinea;
		}
	
public List<Collegamento> getAllCollegamenti(List<Stop> stops,List<Route> routes,LocalDateTime date) {
		
		TesiDAO dao = new TesiDAO();
	
		collegamenti = dao.getAllCollegamenti(stops,routes,date);
		return collegamenti;
		}
	

	
	public List<StopCollegati> getAllStopsVicini(List<Stop> stops) {
		TesiDAO dao = new TesiDAO();
		return dao.getAllStopsVicini(stops);
	}
	
	public List<MuseoCollegatoStop> getAllMuseiCollegatiFermate(List<Stop> stops, List<Museo> musei) {
		TesiDAO dao = new TesiDAO();
		return dao.getAllMuseiCollegatiFermate(stops, musei);
	}
	
	public List<Museo> getAllMusei() {
		TesiDAO dao = new TesiDAO();
		musei = dao.getAllMusei();
		return musei;
	}
	public List<Museo> getAllMuseiAperti(int dow) {
		museiAperti.clear();
		for(Museo m : musei)
			{
			this.getAllOrariMuseiByMuseoIdGiornoSettimana(m.getId(), dow, musei);
			if(m.getOrarioApertura()!=null)
				museiAperti.add(m);
			}
			
		return museiAperti;
	}
	
	public void  getAllAtteseByRoute(int dow,LocalTime time,List<Route> routes) {
		TesiDAO dao = new TesiDAO();
		dao.getAllAtteseByRoute(dow, time, routes);
		
	}
	
	public void getAllOrariMuseiByMuseoIdGiornoSettimana(int museoId,int dow,List<Museo> musei) {
		TesiDAO dao = new TesiDAO();
		dao.getAllOrariMuseiByMuseoIdGiornoSettimana(museoId, dow, musei);
	}
	
	
	
	public List<Museo> getDaVisitare() {
		return daVisitare;
	}

	public void setDaVisitare(List<Museo> daVisitare) {
		this.daVisitare = daVisitare;
	}
	

	public boolean isCompleto() {
		return completo;
	}

	public void setCompleto(boolean completo) {
		this.completo = completo;
	}
	public List<MuseoVicinoMusei> getAllMuseiViciniMusei(List<Museo> musei) {
		TesiDAO dao = new TesiDAO();
		return dao.getAllMuseiViciniMusei(musei);
	}

	public void creaVertici (LocalDate date)
	{
		graphParziale = new DefaultDirectedWeightedGraph<Luogo,DefaultWeightedEdge>(DefaultWeightedEdge.class);
	
		this.getAllRoutes();
		this.getAllStops();
		this.getAllStopsSuLinea(stops, routes);
		//this.getAllMusei();
			
		Graphs.addAllVertices(graphParziale, stopSuLinea);
		List<Museo> chiusi = new ArrayList<Museo>();
		/*for(Museo m : daVisitare)
		{
			this.getAllOrariMuseiByMuseoIdGiornoSettimana(m.getId(), date.getDayOfWeek().getValue(), daVisitare);
		}*/
		/*for(Museo m : daVisitare)
			if(m.getOrarioApertura()==null)
				{
					//UN MUSEO E' CHIUSO
					aperti=false;
					chiusi.add(m);
				}
		for(Museo m : chiusi)
			daVisitare.remove(m);*/
		
		
	}
	
	public void collegaMusei(List<Museo> daVisitare)
	{
		//AGGIUNGO COLLEGAMENTO TRA I MUSEI E LE SUE STAZIONI VICINE
		for(MuseoCollegatoStop museoCollegato : this.getAllMuseiCollegatiFermate(stops, daVisitare))
		{
			for(StopSuLinea stl : museoCollegato.getStops().getStopSuLinea())
			{
				double tempo = (museoCollegato.getDistanza()*1000/1)/60; //VELOCITA UOMO A PIEDI 1 m/s
				Graphs.addEdge(graph,museoCollegato.getMuseo(), stl, tempo+stl.getRoute().getAttesa());
				Graphs.addEdge(graph,stl,museoCollegato.getMuseo(), tempo);
			}
			
		}
	}
	public void collegaStazioniVicine()
	{
		//AGGIUNGO COLLEGAMENTO FRA STAZIONI VICINE
		for(StopCollegati s : this.getAllStopsVicini(stops))
		{
			double tempo = (s.getDistanza()*1000/1)/60; //VELOCITA UOMO A PIEDI 1 m/s 
			for(StopSuLinea stl1 : s.getS1().getStopSuLinea())
				for(StopSuLinea stl2 : s.getS2().getStopSuLinea())
					{
						Graphs.addEdge(graph,stl1, stl2, stl2.getRoute().getAttesa()+tempo);
						Graphs.addEdge(graph,stl2,stl1,stl1.getRoute().getAttesa()+tempo);
					}
		}
	}
	public void creaArchi(LocalDateTime date)
	{
		List<Collegamento> collegamenti = this.getAllCollegamenti(stops, routes,date);
		for(Collegamento c : collegamenti)
			{
			//try{
				List<StopSuLinea> stopSuLineaPerStopPartenza = c.getPartenza().getStopSuLinea();
				StopSuLinea stopSuLineaPartenza = stopSuLineaPerStopPartenza.get(stopSuLineaPerStopPartenza.indexOf(new StopSuLinea(c.getPartenza(),c.getRoute())));
			//}
			//catch(Exception e)
			//System.out.print("primo "+c.getPartenza()+" "+c.getPartenza().getStopSuLinea()+"\n");
			
			//try{
				List<StopSuLinea> stopSuLineaPerStopArrivo = c.getArrivo().getStopSuLinea();
				StopSuLinea stopSuLineaArrivo = stopSuLineaPerStopArrivo.get(stopSuLineaPerStopArrivo.indexOf(new StopSuLinea(c.getArrivo(),c.getRoute())));
			//}
			//catch(Exception e)
			//System.out.print("secodno "+c.getArrivo()+" "+c.getArrivo().getStopSuLinea()+"\n");
			
			
				Graphs.addEdge(graph, stopSuLineaPartenza, stopSuLineaArrivo,c.getTempo());
			
			}
			
	
			this.getAllAtteseByRoute(date.getDayOfWeek().getValue(), date.toLocalTime(), routes);
			
			for(Stop stop : stops)
				for(StopSuLinea partenza : stop.getStopSuLinea())
					for(StopSuLinea arrivo : stop.getStopSuLinea())
						if(!partenza.equals(arrivo))
							{
								Graphs.addEdge(graph, partenza, arrivo, arrivo.getRoute().getAttesa()); //TEMPO DI CAMBIO LINEA 
							}
			
			
			this.collegaMusei(daVisitare);
			this.collegaStazioniVicine();	
			
	
	}
	
	public boolean museoAperto (Museo m, LocalDateTime date)
	{
		if(date.toLocalTime().plusMinutes(tempoPercorso).isAfter(m.getOrarioApertura()) 
				&&	date.toLocalTime().plusMinutes(tempoPercorso).isBefore(m.getOrarioChiusura().minusMinutes(m.getTempoVisita())) ) //SE IN QUESTO MOMENTO IL MUSEO E APERTO
			{
				tempoPercorso+=m.getTempoVisita(); //TEMPO DI VISITA  MUSEO
				return true;
			}
			else if( date.toLocalTime().plusMinutes(tempoPercorso).isBefore(m.getOrarioApertura()) ) //SE QUANDO ARRIVO IL MUSEO DEVE ANCORA APRIRE
			{
				tempoPercorso+=m.getTempoVisita(); //TEMPO DI VISITA  MUSEO
				long attesa = (m.getOrarioApertura().getHour()-date.toLocalTime().plusMinutes(tempoPercorso).getHour())*60+(m.getOrarioApertura().getMinute()-date.toLocalTime().plusMinutes(tempoPercorso).getMinute());
				tempoPercorso+=attesa;//TEMPO ATTESA APERTURA
				return true;
			}
			else  //PERRCORSO PARZIALE NON COMPLETABILE
			{
				return false;
			}
		
	}
	
	
	
	/*public void camminoMinimo(Luogo museoPartenza, Luogo museoArrivo)
	{
		DijkstraShortestPath<Luogo,DefaultWeightedEdge> dijkstra;
		
		double tempo=0;
		double tempoMinimo = 24*60;
		List<DefaultWeightedEdge> camminoMinimo = null;
		for(StopSuLinea partenzaSuLinea : partenza.getStopSuLinea()){  
			for(StopSuLinea arrivoSuLinea : arrivo.getStopSuLinea()){
				dijkstra = new DijkstraShortestPath<Luogo,DefaultWeightedEdge>(graph,partenzaSuLinea,arrivoSuLinea);
				tempo = dijkstra.getPathLength();
				
				if(tempo<tempoMinimo)
				{
					tempoMinimo=tempo;
					camminoMinimo=dijkstra.getPathEdgeList();
				}
			}
		}
		dijkstra = new DijkstraShortestPath<Luogo,DefaultWeightedEdge>(graph,museoPartenza,museoArrivo);
		//tempoPercorso=tempoMinimo;
		//percorso=camminoMinimo;
		tempoPercorso=dijkstra.getPathLength();
		percorso=dijkstra.getPathEdgeList();

	}*/
	
	public void trovaPercorsiPossibili(int passo,List<Museo> daVisitare,List<Museo> percorsoParziale,int numeroMuseiDaVisitare,List<List<Museo>> percorsiTotale)
	{
		//tempoMigliore=24*60;
		
			if(passo==numeroMuseiDaVisitare)
			{
				//FINTO UN PERCORSO
				/*if(tempoParziale<tempoMigliore)
				{
					percorsoMigliore.clear();
					percorsoMigliore.addAll(percorsoMigliore);
					tempoMigliore=tempoParziale;
				}*/
				percorsiTotale.add(new ArrayList<Museo>(percorsoParziale));
			}
			else{
				for(int i=0;i<daVisitare.size();i++)
				{
				//DijkstraShortestPath<Luogo,DefaultWeightedEdge> dijkstra = new DijkstraShortestPath<Luogo,DefaultWeightedEdge>(graph,museoPartenza,museoArrivo);
					if(!percorsoParziale.contains(daVisitare.get(i)))
					{
						percorsoParziale.add(daVisitare.get(i));
						this.trovaPercorsiPossibili(passo+1, daVisitare, percorsoParziale, numeroMuseiDaVisitare, percorsiTotale);
						percorsoParziale.remove(percorsoParziale.size()-1);
					}
				}
				

				}
		
	}
	
	public List<DefaultWeightedEdge> percorsoMigliore(List<List<Museo>> percorsiTotale,LocalDateTime date)
	{
		percorsoMigliore = new ArrayList<DefaultWeightedEdge>();
		//tuttiIpercorsi = new ArrayList<List<DefaultWeightedEdge>>();
		percorsoIncompleto = new ArrayList<DefaultWeightedEdge>();
		
		//Graphs.addAllVertices(graph,daVisitare);
		Graphs.addAllVertices(graphParziale, daVisitare);
		for(MuseoVicinoMusei mvm : this.getAllMuseiViciniMusei(musei))
		{
			if(daVisitare.contains(mvm.getPartenza()) && daVisitare.contains(mvm.getArrivo()))
				{
					Graphs.addEdge(graphParziale, mvm.getPartenza(), mvm.getArrivo(), (mvm.getDistanza()*1000/1)/60);  //CREO ARCHI FRA MUSEI VICINI MENO DI 500 METRI
					Graphs.addEdge(graphParziale, mvm.getArrivo(),  mvm.getPartenza(), (mvm.getDistanza()*1000/1)/60);
				}
		}
		//System.out.print(graph.edgeSet());
		
		//this.collegaMusei(daVisitare);
		//this.collegaStazioniVicine();
		int percorsoCompleto=0;
		//for(int i=0;i<percorsiTotale.size();i++)
		for(int i=1;i<percorsiTotale.size();i++)
		{
			long tempoPercorso=0;
			
			
			List<DefaultWeightedEdge> percorso = new ArrayList<DefaultWeightedEdge>();
			int visitati=0;
			List<Integer> posizione = new ArrayList<Integer>();
 			long tempoParziale=0;
			List<DefaultWeightedEdge> percorsoParziale =  new ArrayList<DefaultWeightedEdge>();
			
			boolean percorsoCorretto = true;
			
			
 			for(int j=0;j<percorsiTotale.get(i).size()-1;j++)
			{
				
				if(tempoPercorso<tempoMigliore) //CALCOLO I PERCORSI SOLO SE POSSONO ESSERE I MIGLIORI
				{
					if(percorsoCorretto==true)
					{
						if(date.toLocalTime().plusMinutes(tempoPercorso).isAfter(percorsiTotale.get(i).get(j).getOrarioApertura()) 
							&&	date.toLocalTime().plusMinutes(tempoPercorso).isBefore(percorsiTotale.get(i).get(j).getOrarioChiusura().minusMinutes(percorsiTotale.get(i).get(j).getTempoVisita())) ) //SE IN QUESTO MOMENTO IL MUSEO E APERTO
						{
							tempoPercorso+=percorsiTotale.get(i).get(j).getTempoVisita(); //TEMPO DI VISITA  MUSEO
							visitati++;
						}
						else if( date.toLocalTime().plusMinutes(tempoPercorso).isBefore(percorsiTotale.get(i).get(j).getOrarioApertura()) ) //SE QUANDO ARRIVO IL MUSEO DEVE ANCORA APRIRE
						{
							
							long attesa = (percorsiTotale.get(i).get(j).getOrarioApertura().getHour()-date.toLocalTime().plusMinutes(tempoPercorso).getHour())*60+(percorsiTotale.get(i).get(j).getOrarioApertura().getMinute()-date.toLocalTime().plusMinutes(tempoPercorso).getMinute());
							tempoPercorso+=percorsiTotale.get(i).get(j).getTempoVisita(); //TEMPO DI VISITA  MUSEO
							tempoPercorso+=attesa;//TEMPO ATTESA APERTURA
							visitati++;
						}
						else  //PERRCORSO PARZIALE NON COMPLETABILE
						{
							percorsoCorretto=false;
							if(visitati>visitatiPercorsoIncompleto)
							{
								visitatiPercorsoIncompleto=visitati;
								tempoPercorsoIncompletoMigliore=tempoParziale;
								percorsoIncompleto.clear();
								if(percorsoParziale.size()!=0)
									{
										unicoMuseo=false;
										percorsoIncompleto.addAll(new ArrayList<DefaultWeightedEdge>(percorsoParziale));
										//System.out.println("gasdotto");
										posizioniMiglioriIncompleto.clear();
										posizioniMiglioriIncompleto.addAll(new ArrayList<Integer>(posizione));
									}
								else
								{
									unicoMuseo=true;
									unicoMuseoVisitato=percorsiTotale.get(i).get(j-1);
									//System.out.println("caso1"+percorsiTotale.get(i).get(j-1)+" "+tempoParziale);
									//percorsoIncompleto.add(new DefaultWeightedEdge());
								}
									
							}
							else if(visitati==visitatiPercorsoIncompleto && tempoParziale>0)
							{
								if(tempoParziale<tempoPercorsoIncompletoMigliore)
								{
									tempoPercorsoIncompletoMigliore=tempoParziale;
									percorsoIncompleto.clear();
									if(percorsoParziale.size()!=0)
										{
											unicoMuseo=false;
											percorsoIncompleto.addAll(new ArrayList<DefaultWeightedEdge>(percorsoParziale));
											posizioniMiglioriIncompleto.clear();
											posizioniMiglioriIncompleto.addAll(new ArrayList<Integer>(posizione));
										}
									else
										{
											unicoMuseo=true;
											unicoMuseoVisitato=percorsiTotale.get(i).get(j-1);
											//System.out.println("caso2"+percorsiTotale.get(i).get(j-1)+" "+tempoParziale);
											//percorsoIncompleto.add(new DefaultWeightedEdge());
										}
								}
							}
						
						}
						                                                                                                                                                  //E C'E' IL TEMPO DI FINIRE LA SUA VISITA    
							if(percorsoCorretto==true)
							{
								graph = new DefaultDirectedWeightedGraph<Luogo,DefaultWeightedEdge>(DefaultWeightedEdge.class);
									Graphs.addAllVertices(graph, graphParziale.vertexSet());

								for(DefaultWeightedEdge d : graphParziale.edgeSet())
								{
									
									Graphs.addEdge(graph, graphParziale.getEdgeSource(d), graphParziale.getEdgeTarget(d), graphParziale.getEdgeWeight(d));
								}
								this.creaArchi(date.plusMinutes(tempoPercorso)); //CREO GRAFO DI QUANDO ESCO DAL PRIMO MUSEO
								//visitati++; //segno quanti musei visito
							
								DijkstraShortestPath<Luogo,DefaultWeightedEdge> dijkstra = new DijkstraShortestPath<Luogo,DefaultWeightedEdge>(graph,percorsiTotale.get(i).get(j),percorsiTotale.get(i).get(j+1));
								
								tempoParziale = tempoPercorso;
								percorsoParziale.clear();
								 if(percorso.size()>0)
									 percorsoParziale.addAll(new ArrayList<DefaultWeightedEdge>(percorso));
								
								
								if(dijkstra.getPathEdgeList()==null)
								{
									System.out.println("Mancanza percorso    "+percorsiTotale.get(i).get(j)+" "+percorsiTotale.get(i).get(j+1));
									percorsoCorretto=false;
								}
								else
								 {
									tempoPercorso+=(dijkstra.getPathLength());
									percorso.addAll(new ArrayList<DefaultWeightedEdge>(dijkstra.getPathEdgeList()));
									posizione.add(percorso.size()-1);
								 }
								
								if(j==percorsiTotale.get(i).size()-2 ) 		//SE ULTIMO MUSEO DEVO AGGIUNGER IL TEMPO
									{
									if(date.toLocalTime().plusMinutes(tempoPercorso).isAfter(percorsiTotale.get(i).get(j+1).getOrarioApertura()) 
											&&	date.toLocalTime().plusMinutes(tempoPercorso).isBefore(percorsiTotale.get(i).get(j).getOrarioChiusura().minusMinutes(percorsiTotale.get(i).get(j+1).getTempoVisita())) )
										{
											//tuttiIpercorsi.add(new ArrayList<DefaultWeightedEdge>(percorso));
											tempoPercorso+=percorsiTotale.get(i).get(j+1).getTempoVisita();
											visitati++;
										}
									else{
											percorsoCorretto=false;
											unicoMuseo=false;
											if(visitati>visitatiPercorsoIncompleto)
											{
												
												visitatiPercorsoIncompleto=visitati;
												tempoPercorsoIncompletoMigliore=tempoParziale;
												percorsoIncompleto.clear();
												percorsoIncompleto.addAll(new ArrayList<DefaultWeightedEdge>(percorsoParziale));
												posizioniMiglioriIncompleto.clear();
												posizioniMiglioriIncompleto.addAll(new ArrayList<Integer>(posizione));
											}
											else if(visitati==visitatiPercorsoIncompleto)
											{
												
												if(tempoParziale<tempoPercorsoIncompletoMigliore)
												{
													
													tempoPercorsoIncompletoMigliore=tempoParziale;
													percorsoIncompleto.clear();
													percorsoIncompleto.addAll(new ArrayList<DefaultWeightedEdge>(percorsoParziale));
													posizioniMiglioriIncompleto.clear();
													posizioniMiglioriIncompleto.addAll(new ArrayList<Integer>(posizione));
												}
											}
										}
									
									}
							}	
								
						}
					}
			}
			if(tempoPercorso<tempoMigliore && percorsoCorretto==true)
			{
				tempoMigliore=tempoPercorso;
				percorsoMigliore.clear();
				percorsoMigliore.addAll(new ArrayList<DefaultWeightedEdge>(percorso));
				percorsoCompleto++;
				posizioniMigliori.clear();
				posizioniMigliori.addAll(new ArrayList<Integer>(posizione));
				//System.out.println("gas1");
			}
			else if(percorsoCorretto==false)
			{
				if(visitati>visitatiPercorsoIncompleto)
				{
					
					visitatiPercorsoIncompleto=visitati;
					tempoPercorsoIncompletoMigliore=tempoParziale;
					percorsoIncompleto.clear();
					percorsoIncompleto.addAll(new ArrayList<DefaultWeightedEdge>(percorsoParziale));
					posizioniMiglioriIncompleto.clear();
					posizioniMiglioriIncompleto.addAll(new ArrayList<Integer>(posizione));
				}
				else if(visitati==visitatiPercorsoIncompleto)
				{
					
					if(tempoParziale<tempoPercorsoIncompletoMigliore)
					{
						
						tempoPercorsoIncompletoMigliore=tempoParziale;
						percorsoIncompleto.clear();
						percorsoIncompleto.addAll(new ArrayList<DefaultWeightedEdge>(percorsoParziale));
						posizioniMiglioriIncompleto.clear();
						posizioniMiglioriIncompleto.addAll(posizione);
					}
				}
				
			}
		}
		if(percorsoCompleto>0 ) //almeno un percorso completo
		{
			//System.out.println("boom");
			/*if(aperti==true)
				completo=true;
			else
			{
				completo=false;
			}*/
			completo=true;
			
			//System.out.println(percorsoMigliore);
			return percorsoMigliore;
		}
		else //RESTITUISCO IL MIGLIORE PERCORSO INCOMPLETO
		{
			completo=false;
			//System.out.println("gas2");
			return percorsoIncompleto;
		}
	}
	
	public String stampaRisultato(List<DefaultWeightedEdge> percorso)
	{
		boolean primo=true;
		boolean primaMuseo=false;
		boolean noMuseo=false;
		int fermate=0;
 		String risultato = "";
		for(int i=0;i<percorso.size();i++)
		{
			DefaultWeightedEdge d = percorso.get(i);
			DefaultWeightedEdge dSuccessivo = null;
			DefaultWeightedEdge dPrecedente = null;
					
			if(i<percorso.size()-1)
				{
				 dSuccessivo = percorso.get(i+1);
				}
			if(i!=0)
				 dPrecedente = percorso.get(i-1);
			
		if(this.graph.getEdgeSource(d) instanceof Museo && primo==true)
			{
				Museo museo = (Museo) this.graph.getEdgeSource(d);
				risultato+="Visita di : "+museo.getNome()+". Tempo visita "+museo.getTempoVisita()+" minuti \n";
				primo=false;
				//primaMuseo=true;
			}
		 if(this.graph.getEdgeSource(d) instanceof Museo && this.graph.getEdgeTarget(d) instanceof StopSuLinea)
			{
			 	primaMuseo=true;
				//StopSuLinea s = (StopSuLinea) this.graph.getEdgeTarget(d);
				//risultato+="Prendere la linea "+s.getRoute().getShortName()+" alla  "+s.getNome();
			}
		 if(this.graph.getEdgeSource(d) instanceof StopSuLinea && this.graph.getEdgeTarget(d) instanceof Museo && posizioniMigliori.contains(i))
			{
				 if(noMuseo==false )
				 {
					 if(fermate==1 )
							risultato+=" per "+fermate+" fermata \n";
						else if( fermate!=0)
							risultato+=" per "+fermate+" fermate \n";
					fermate=0;
					
					Museo museo = (Museo) this.graph.getEdgeTarget(d);
					StopSuLinea p = (StopSuLinea) this.graph.getEdgeSource(d);
					risultato+="Scendere alla fermata "+p.getNome()+"\n";
					risultato+="Visita di  : "+museo.getNome()+". Tempo visita "+museo.getTempoVisita()+" minuti \n";
				 }
				 else
					 noMuseo=false;
				//risultato+="\n";
			}
			
			 if(this.graph.getEdgeSource(d) instanceof Museo && this.graph.getEdgeTarget(d) instanceof Museo && posizioniMigliori.contains(i))
			 {
				 Museo museo = (Museo) this.graph.getEdgeTarget(d);
				 risultato+="Raggiungi a piedi il museo"+museo.getNome()+"\n";
				 //if(percorso.indexOf(d)==percorso.size()-1) //sarebbe l'ultimo arco
					 risultato+="Visita di  : "+museo.getNome()+". Tempo visita "+museo.getTempoVisita()+" minuti \n";
			 }
		 if(this.graph.getEdgeSource(d) instanceof StopSuLinea  && this.graph.getEdgeTarget(d) instanceof StopSuLinea)
		{

			StopSuLinea p = (StopSuLinea) this.graph.getEdgeSource(d);
			StopSuLinea a= (StopSuLinea) this.graph.getEdgeTarget(d);
			if(p.getRoute().getRouteId()!=a.getRoute().getRouteId() && p.getStopId()==a.getStopId())
				{
					
						
						if(fermate==1)
							risultato+=" per "+fermate+" fermata \n";
						else if(fermate!=0)
							risultato+=" per "+fermate+" fermate \n";
						
						if( this.graph.getEdgeTarget(dSuccessivo) instanceof StopSuLinea)
						{
							StopSuLinea ss= (StopSuLinea) this.graph.getEdgeTarget(dSuccessivo);
							if(ss.getRoute().getRouteId()==a.getRoute().getRouteId())
								risultato+="Cambiare linea alla "+p.getNome()+". Passare dalla linea "+p.getRoute().getShortName()+" alla linea "+a.getRoute().getShortName();
							else
								risultato+="Raggiungi a piedi la fermata "+ss.getNome()+" e prendi la linea"+ss.getRoute().getShortName();
							fermate=0;
						}
						else if(this.graph.getEdgeTarget(dSuccessivo) instanceof Museo && posizioniMigliori.contains(i+1) )
						{
							Museo m = (Museo) this.graph.getEdgeTarget(dSuccessivo);
							risultato+="Scendi alla fermata"+p.getNome();
							risultato+="Visita di  : "+m.getNome()+". Tempo visita "+m.getTempoVisita()+" minuti \n";
							noMuseo=true;
						}
					
					primaMuseo=false;
				}
			else if(p.getRoute().getRouteId()!=a.getRoute().getRouteId() && p.getStopId()!=a.getStopId() )
			{
				if(primaMuseo==true)
				{
					risultato+="Prendi la linea "+a.getRoute().getShortName()+" alla  "+a.getNome();
					fermate=0;
					primaMuseo=false;
				}
				else
				{
				 if(fermate==1)
					risultato+=" per "+fermate+" fermata \n";
				else if( fermate!=0)
					risultato+=" per "+fermate+" fermate \n";
				 if( this.graph.getEdgeTarget(dSuccessivo) instanceof StopSuLinea)
					{
						StopSuLinea ss= (StopSuLinea) this.graph.getEdgeTarget(dSuccessivo);
						if(ss.getRoute().getRouteId()==a.getRoute().getRouteId())
							risultato+="Scendere alla fermata "+p.getNome()+" e raggiungere a piedi la fermata "+a.getNome()+" dove prendere la linea "+a.getRoute().getShortName();
						else
							{
								risultato+="Raggiungi a piedi la fermata "+ss.getNome()+" e prendi la linea"+ss.getRoute().getShortName();
								i++;
								
							}
						fermate=0;
					}
				
				fermate=0;
				//primaMuseo=false;
				}
			}
			else
				fermate++;
			if(fermate==1 && primaMuseo==true)
			 {
				 //StopSuLinea s = (StopSuLinea) this.graph.getEdgeSource(d);
				 StopSuLinea sP =  (StopSuLinea) this.graph.getEdgeTarget(dPrecedente);
				risultato+="Prendere la linea "+sP.getRoute().getShortName()+" alla  "+sP.getNome();
				primaMuseo=false;
			 }
		}
		
		
		
		
		}
		
		return risultato;
	}
	
	public static void main(String[] args) {
		Model m = new Model();
		
	System.out.println(LocalTime.now());
	
		/*for(Luogo l : m.graph.vertexSet())
			{
			if(l instanceof Stop)
				if(((Stop) l).getNome().compareTo("Fermata 5043 - VANCHIGLIA")==0)
					System.out.println(l+"\n");
			}*/
		//LocalTime t = LocalTime.now();
	LocalDateTime date = LocalDateTime.of(2016, Month.OCTOBER, 4,10,30,00);
		//m.creaArchi(date);
		//m.collegaMusei();
		//m.collegaStazioniVicine();
		//System.out.println(m.graph.edgeSet().size());
		m.getAllMusei();
		Museo s1 = m.musei.get(m.musei.indexOf(new Museo(46))); //GAM
		Museo s2 = m.musei.get(m.musei.indexOf(new Museo(69))); //MUSEO DEL CINEMA
		Museo s3 = m.musei.get(m.musei.indexOf(new Museo(59))); //EGIZIO
		//Museo s4 = m.musei.get(m.musei.indexOf(new Museo(31))); //ARMERIA
		
		//List<Museo> daVisitare = new ArrayList<Museo>();
		m.daVisitare.add(s3);
		m.daVisitare.add(s1);
		m.daVisitare.add(s2);
		//m.daVisitare.add(s4);
		
		List<List<Museo>> percorsiTotale = new ArrayList<List<Museo>>();
		List<Museo> percorsoParziale = new ArrayList<Museo>();
		m.getAllMuseiAperti(date.getDayOfWeek().getValue());
		m.creaVertici(date.toLocalDate());
		m.trovaPercorsiPossibili(0, m.daVisitare, percorsoParziale, m.daVisitare.size(), percorsiTotale);
		//System.out.print(percorsiTotale);
		//System.out.println(percorsiTotale+"\n"+percorsiTotale.size());
		//DijkstraShortestPath<Luogo,DefaultWeightedEdge> dijkstra = new DijkstraShortestPath<Luogo,DefaultWeightedEdge>(m.graph,s1,s3);
		//System.out.println(dijkstra.getPathLength());
		//System.out.println(dijkstra.getPath());
		
		
		
		List<DefaultWeightedEdge> percorso = m.percorsoMigliore(percorsiTotale, date);
		if(m.isCompleto()==true)
			{	
				//System.out.println(percorso);
			/*boolean primo=true;
			int fermate=0;
			for(DefaultWeightedEdge d : percorso)
				{
				if(m.graph.getEdgeSource(d) instanceof Museo && primo==true)
					{
						Museo museo = (Museo) m.graph.getEdgeSource(d);
						System.out.println("Visita di : "+museo.getNome()+". Tempo visita "+museo.getTempoVisita()+" minuti");
						primo=false;
					}
				 if(m.graph.getEdgeSource(d) instanceof Museo && m.graph.getEdgeTarget(d) instanceof StopSuLinea)
					{
					StopSuLinea s = (StopSuLinea) m.graph.getEdgeTarget(d);
					System.out.print("Prendere la linea "+s.getRoute().getShortName()+" alla  "+s.getNome());
					}
				 if(m.graph.getEdgeSource(d) instanceof StopSuLinea  && m.graph.getEdgeTarget(d) instanceof StopSuLinea)
				{
					
					
					StopSuLinea p = (StopSuLinea) m.graph.getEdgeSource(d);
					StopSuLinea a= (StopSuLinea) m.graph.getEdgeTarget(d);
					if(p.getRoute().getRouteId()!=a.getRoute().getRouteId() && p.getStopId()==a.getStopId())
						{
							if(fermate==1)
								System.out.println(" per "+fermate+" fermata");
							else
								System.out.println(" per "+fermate+" fermate");
							System.out.print("Cambiare linea alla "+p.getNome()+". Passare dalla linea "+p.getRoute().getShortName()+" alla linea "+a.getRoute().getShortName());
							fermate=0;
						}
					else if(p.getRoute().getRouteId()!=a.getRoute().getRouteId() && p.getStopId()!=a.getStopId())
					{
						if(fermate==1)
							System.out.println(" per "+fermate+" fermata");
						else
							System.out.println(" per "+fermate+" fermate");
						System.out.print("Scendere alla fermata "+p.getNome()+" e raggiungi a piedi la fermata "+a.getNome()+" e prendi la linea "+a.getRoute().getShortName());
						fermate=0;
					}
					else
						fermate++;
				}
				 if(m.graph.getEdgeSource(d) instanceof StopSuLinea && m.graph.getEdgeTarget(d) instanceof Museo)
				{
					 if(fermate==1)
							System.out.println(" per "+fermate+" fermata");
						else
							System.out.println(" per "+fermate+" fermate");
					fermate=0;
					
					Museo museo = (Museo) m.graph.getEdgeTarget(d);
					StopSuLinea p = (StopSuLinea) m.graph.getEdgeSource(d);
					System.out.println("Scendere alla fermata "+p.getNome());
					System.out.println("Visita di  : "+museo.getNome()+". Tempo visita "+museo.getTempoVisita()+" minuti");
				}
				
				
				
				
				}*/
			System.out.println("Il percorso � completo");
			System.out.println(m.stampaRisultato(percorso));
				System.out.println("Tempo percorso totale : "+m.tempoMigliore);
				System.out.println(percorso);
			}
		else if(m.unicoMuseo==true)
			{
			System.out.println("Si pu� visitare un unico museo");
				System.out.println(m.unicoMuseoVisitato);
				//System.out.println(m.tempoPercorsoIncompletoMigliore);
			}
		else
		{	
			//System.out.println(percorso);
			System.out.println("Il percorso non � completo");
			System.out.println(m.stampaRisultato(percorso));
			System.out.println("Tempo del percorso: "+m.tempoPercorsoIncompletoMigliore);
		}
		
		/*for(DefaultWeightedEdge d : percorso)
			m.graph.getEdgeSource(d);*/
		
		
		
		//System.out.println(m.percorsoMigliore);
		/*for(int i=0;i<m.tuttiIpercorsi.size();i++)
			System.out.println(m.tuttiIpercorsi.get(i));*/
		
//////////////////////////////////////////m.camminoMinimo(s1, s2);
		 
//System.out.println(m.percorsoMigliore);
//System.out.println(m.tempoMigliore);
		//System.out.println(Graphs.neighborListOf(m.graph, s1));
		/*m.getAllCollegamenti(m.getAllStops(), m.getAllRoutes(), date);
		for(Collegamento c : m.collegamenti)
			if(c.getPartenza().getStopId()==52128004)
				System.out.println(c.getPartenza()+" "+c.getArrivo()+" "+c.getRoute().getShortName()+" "+c.getTempo());*/
		/*for(Route r : m.getAllRoutes())
			{
				m.getAllAtteseByRoute(r.getRouteId(),date.getDayOfWeek().getValue()+1 , date.toLocalTime(), m.routes);
				System.out.println(r.getAttesa()+"       "+r.getLongName()+ " "+ r.getRouteId());
			}*/
			
System.out.println(LocalTime.now());
		
		
		
	}

	public double getTempoMigliore() {
		return tempoMigliore;
	}

	public void setTempoMigliore(double tempoMigliore) {
		this.tempoMigliore = tempoMigliore;
	}

	public long getTempoPercorsoIncompletoMigliore() {
		return tempoPercorsoIncompletoMigliore;
	}

	public void setTempoPercorsoIncompletoMigliore(long tempoPercorsoIncompletoMigliore) {
		this.tempoPercorsoIncompletoMigliore = tempoPercorsoIncompletoMigliore;
	}

	public boolean isUnicoMuseo() {
		return unicoMuseo;
	}

	public void setUnicoMuseo(boolean unicoMuseo) {
		this.unicoMuseo = unicoMuseo;
	}

	public Museo getUnicoMuseoVisitato() {
		return unicoMuseoVisitato;
	}

	public void setUnicoMuseoVisitato(Museo unicoMuseoVisitato) {
		this.unicoMuseoVisitato = unicoMuseoVisitato;
	}
	
	
}
