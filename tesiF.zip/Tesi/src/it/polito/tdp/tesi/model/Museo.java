package it.polito.tdp.tesi.model;

import java.time.LocalTime;

public class Museo extends Luogo{
	int id;
	String nome;
	String indirizzo;
	double latitudine;
	double longitudine;
	long tempoVisita;
	LocalTime orarioApertura;
	LocalTime orarioChiusura;
	
	public LocalTime getOrarioApertura() {
		return orarioApertura;
	}
	public void setOrarioApertura(LocalTime orarioApertura) {
		this.orarioApertura = orarioApertura;
	}
	public LocalTime getOrarioChiusura() {
		return orarioChiusura;
	}
	public void setOrarioChiusura(LocalTime orarioChiusura) {
		this.orarioChiusura = orarioChiusura;
	}
	public long getTempoVisita() {
		return tempoVisita;
	}
	public void setTempoVisita(long tempoVisita) {
		this.tempoVisita = tempoVisita;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getIndirizzo() {
		return indirizzo;
	}
	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}
	public double getLatitudine() {
		return latitudine;
	}
	public void setLatitudine(double latitudine) {
		this.latitudine = latitudine;
	}
	public double getLongitudine() {
		return longitudine;
	}
	public void setLongitudine(double longitudine) {
		this.longitudine = longitudine;
	}
	@Override
	public String toString() {
		return  nome ;
	}

	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Museo other = (Museo) obj;
		if (id != other.id)
			return false;
		return true;
	}
	public Museo(int id, String nome, String indirizzo, double latitudine, double longitudine,long tempoVisita) {
		super();
		this.id = id;
		this.nome = nome;
		this.indirizzo = indirizzo;
		this.latitudine = latitudine;
		this.longitudine = longitudine;
		this.tempoVisita=tempoVisita;
	}
	public Museo(int idMuseo) {
		this.id=idMuseo;
	}
	
	

}
