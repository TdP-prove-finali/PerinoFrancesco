package it.polito.tdp.tesi.model;



import it.polito.tdp.tesi.model.Museo;
import it.polito.tdp.tesi.model.Stop;


public class MuseoCollegatoStop {
	
	Museo museo;
	Stop stops;
	double distanza;
	public Museo getMuseo() {
		return museo;
	}
	public void setMuseo(Museo museo) {
		this.museo = museo;
	}
	public Stop getStops() {
		return stops;
	}
	public void setStops(Stop stops) {
		this.stops = stops;
	}
	public double getDistanza() {
		return distanza;
	}
	public void setDistanza(double distanza) {
		this.distanza = distanza;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		long temp;
		temp = Double.doubleToLongBits(distanza);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((museo == null) ? 0 : museo.hashCode());
		result = prime * result + ((stops == null) ? 0 : stops.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MuseoCollegatoStop other = (MuseoCollegatoStop) obj;
		if (Double.doubleToLongBits(distanza) != Double.doubleToLongBits(other.distanza))
			return false;
		if (museo == null) {
			if (other.museo != null)
				return false;
		} else if (!museo.equals(other.museo))
			return false;
		if (stops == null) {
			if (other.stops != null)
				return false;
		} else if (!stops.equals(other.stops))
			return false;
		return true;
	}
	public MuseoCollegatoStop(Museo museo, Stop stops, double distanza) {
		super();
		this.museo = museo;
		this.stops = stops;
		this.distanza = distanza;
	}
	

}
