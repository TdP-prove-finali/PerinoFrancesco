package it.polito.tdp.tesi.model;

public class MuseoVicinoMusei {
	
	Museo partenza;
	Museo arrivo;
	double distanza;
	public Museo getPartenza() {
		return partenza;
	}
	public void setPartenza(Museo partenza) {
		this.partenza = partenza;
	}
	public Museo getArrivo() {
		return arrivo;
	}
	public void setArrivo(Museo arrivo) {
		this.arrivo = arrivo;
	}
	public double getDistanza() {
		return distanza;
	}
	public void setDistanza(double distanza) {
		this.distanza = distanza;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((arrivo == null) ? 0 : arrivo.hashCode());
		long temp;
		temp = Double.doubleToLongBits(distanza);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + ((partenza == null) ? 0 : partenza.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		MuseoVicinoMusei other = (MuseoVicinoMusei) obj;
		if (arrivo == null) {
			if (other.arrivo != null)
				return false;
		} else if (!arrivo.equals(other.arrivo))
			return false;
		if (Double.doubleToLongBits(distanza) != Double.doubleToLongBits(other.distanza))
			return false;
		if (partenza == null) {
			if (other.partenza != null)
				return false;
		} else if (!partenza.equals(other.partenza))
			return false;
		return true;
	}
	public MuseoVicinoMusei(Museo partenza, Museo arrivo, double distanza2) {
		super();
		this.partenza = partenza;
		this.arrivo = arrivo;
		this.distanza = distanza2;
	}
	
	
	

}
