package it.polito.tdp.tesi.model;

public class StopSuLinea extends Stop{

	private Route route;
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = super.hashCode();
		result = prime * result + ((route == null) ? 0 : route.hashCode());
		return result;
	}

	@Override
	public String toString() {
		return "Stop ["+this.getNome()+" Linea"+getRoute().getShortName()+"]";
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (!super.equals(obj))
			return false;
		if (getClass() != obj.getClass())
			return false;
		StopSuLinea other = (StopSuLinea) obj;
		if (route == null) {
			if (other.route != null)
				return false;
		} else if (!route.equals(other.route))
			return false;
		return true;
	}

	public StopSuLinea(Stop stop, Route route) {
		super(stop.getStopId(),stop.stopCode,stop.getNome(),stop.getLongitudine(),stop.getLongitudine());
		this.route=route;
	}

	public Route getRoute() {
		return route;
	}

	public void setRoute(Route route) {
		this.route = route;
	}

	
	

}
