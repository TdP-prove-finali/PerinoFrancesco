package it.polito.tdp.tesi.model;

import java.time.LocalTime;

public class StopTime {
	
	public StopTime(int trip_id, int stop_id, int stop_sequence, LocalTime arrival_time, LocalTime departure_time) {
		super();
		this.trip_id = trip_id;
		this.stop_id = stop_id;
		this.stop_sequence = stop_sequence;
		this.arrival_time = arrival_time;
		this.departure_time = departure_time;
	}
	int trip_id;
	int stop_id;
	int stop_sequence;
	LocalTime arrival_time;
	LocalTime departure_time;
	public int getTrip_id() {
		return trip_id;
	}
	public void setTrip_id(int trip_id) {
		this.trip_id = trip_id;
	}
	public int getStop_id() {
		return stop_id;
	}
	public void setStop_id(int stop_id) {
		this.stop_id = stop_id;
	}
	public int getStop_sequence() {
		return stop_sequence;
	}
	public void setStop_sequence(int stop_sequence) {
		this.stop_sequence = stop_sequence;
	}
	public LocalTime getArrival_time() {
		return arrival_time;
	}
	public void setArrival_time(LocalTime arrival_time) {
		this.arrival_time = arrival_time;
	}
	public LocalTime getDeparture_time() {
		return departure_time;
	}
	public void setDeparture_time(LocalTime departure_time) {
		this.departure_time = departure_time;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + stop_id;
		result = prime * result + trip_id;
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StopTime other = (StopTime) obj;
		if (stop_id != other.stop_id)
			return false;
		if (trip_id != other.trip_id)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "StopTime [trip_id=" + trip_id + ", stop_id=" + stop_id + ", stop_sequence=" + stop_sequence
				+ ", arrival_time=" + arrival_time + ", departure_time=" + departure_time + "]";
	}
	
	
	
	

}
