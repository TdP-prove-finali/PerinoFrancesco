package it.polito.tdp.tesi.model;

import java.util.ArrayList;
import java.util.List;

public class Stop extends Luogo{
	
	public Stop(int stopId, int stopCode, String nome, double latitudine, double longitudine) {
		super();
		this.stopId = stopId;
		this.stopCode = stopCode;
		this.nome = nome;
		this.latitudine = latitudine;
		this.longitudine = longitudine;
		this.stopSuLinea = new ArrayList<StopSuLinea>();
	}
	public Stop(int stopId)
	{
		this.stopId = stopId;
	}
	int stopId;
	int stopCode;
	String nome;
	double latitudine;
	double longitudine;
	List<StopSuLinea> stopSuLinea;
	public int getStopId() {
		return stopId;
	}
	public void setStopId(int stopId) {
		this.stopId = stopId;
	}
	public int getStopCode() {
		return stopCode;
	}
	public void setStopCode(int stopCode) {
		this.stopCode = stopCode;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public double getLatitudine() {
		return latitudine;
	}
	public void setLatitudine(double latitudine) {
		this.latitudine = latitudine;
	}
	public double getLongitudine() {
		return longitudine;
	}
	public void setLongitudine(double longitudine) {
		this.longitudine = longitudine;
	}
	public void addStopSuLinea(StopSuLinea stl)
	{
		stopSuLinea.add(stl);
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + stopId;
		return result;
	}
	public List<StopSuLinea> getStopSuLinea() {
		return stopSuLinea;
	}
	public void setStopSuLinea(List<StopSuLinea> stopSuLinea) {
		this.stopSuLinea = stopSuLinea;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Stop other = (Stop) obj;
		if (stopId != other.stopId)
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Stop [nome=" + nome + "]";
	}
	
	
	

}
